bl_info = {
    "name": "Splat Data Exporter & Batch Renderer",
    "author": "Marek Novotny",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > COLMAP",
    "description": "Generate camera rigs, export COLMAP datasets for Gaussian Splatting, and batch render from multiple cameras",
    "category": "Render",
}

import bpy
import math
import os
import struct
from mathutils import Vector, Matrix, Quaternion
from bpy.props import (
    IntProperty, FloatProperty, StringProperty,
    PointerProperty, BoolProperty
)
from bpy.types import Panel, Operator, PropertyGroup


# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------

class CRCEProperties(PropertyGroup):
    target_object: PointerProperty(
        name="Cíl",
        description="Objekt na který budou kamery namířeny",
        type=bpy.types.Object,
    )
    num_rings: IntProperty(
        name="Počet prstenců",
        default=3,
        min=1,
        max=10,
    )
    cams_per_ring: IntProperty(
        name="Kamer střední",
        default=24,
        min=4,
        max=120,
    )
    cams_per_ring_outer: IntProperty(
        name="Kamer krajní",
        default=16,
        min=4,
        max=120,
    )
    ring_radius: FloatProperty(
        name="Poloměr střední (m)",
        default=2.0,
        min=0.1,
    )
    ring_radius_outer: FloatProperty(
        name="Poloměr krajní (m)",
        default=1.2,
        min=0.1,
    )
    height_min: FloatProperty(
        name="Výška min (m)",
        default=0.3,
    )
    height_max: FloatProperty(
        name="Výška max (m)",
        default=1.5,
    )
    focal_length: FloatProperty(
        name="Ohnisková vzdálenost (mm)",
        default=35.0,
        min=10.0,
        max=200.0,
    )
    output_path: StringProperty(
        name="Výstupní složka",
        default="//colmap_export",
        subtype='DIR_PATH',
    )
    render_images: BoolProperty(
        name="Renderovat snímky",
        default=True,
        description="Renderuje snímky z každé kamery (může trvat dlouho)",
    )
    image_width: IntProperty(
        name="Šířka",
        default=1920,
        min=64,
    )
    image_height: IntProperty(
        name="Výška",
        default=1080,
        min=64,
    )
    lang: bpy.props.EnumProperty(
        name="Jazyk",
        items=[('CZ', 'CZ', 'Čeština'), ('EN', 'EN', 'English')],
        default='CZ',
    )
    source_mesh: PointerProperty(
        name="Zdrojový mesh",
        description="Mesh pro point cloud (prázdné = všechny meshe)",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH',
    )
    use_polar_top: BoolProperty(
        name="Polární shora",
        default=True,
    )
    use_polar_bot: BoolProperty(
        name="Polární zdola",
        default=True,
    )
    use_ring_top: BoolProperty(
        name="Horní prstenec",
        default=True,
    )
    use_ring_bot: BoolProperty(
        name="Dolní prstenec",
        default=True,
    )
    polar_height: FloatProperty(
        name="Výška polárních (m)",
        default=2.5,
        min=0.1,
    )


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class CRCE_OT_CreateRings(Operator):
    bl_idname = "crce.create_rings"
    bl_label = "Vytvořit prstence kamer"
    bl_description = "Vytvoří prstence kamer namířené na vybraný objekt"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.crce_props
        target = props.target_object

        if target is None:
            self.report({'ERROR'}, "Vyber cílový objekt!")
            return {'CANCELLED'}

        target_loc = target.location.copy()
        num_rings = props.num_rings
        cams_per_ring_mid = props.cams_per_ring
        cams_per_ring_outer = props.cams_per_ring_outer
        radius_mid = props.ring_radius
        radius_outer = props.ring_radius_outer
        h_min = props.height_min
        h_max = props.height_max
        fl = props.focal_length

        # Smaž existující CameraRings kolekci i s podkolekcemi
        coll_name = "CameraRings"
        if coll_name in bpy.data.collections:
            old_root = bpy.data.collections[coll_name]
            for child in list(old_root.children):
                for obj in list(child.objects):
                    bpy.data.objects.remove(obj, do_unlink=True)
                bpy.data.collections.remove(child)
            for obj in list(old_root.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.collections.remove(old_root)

        root_coll = bpy.data.collections.new(coll_name)
        context.scene.collection.children.link(root_coll)

        cam_count = 0
        for ring_i in range(num_rings):
            is_bottom = (ring_i == 0)
            is_top = (ring_i == num_rings - 1) and num_rings > 1

            # Přeskočit krajní prstence podle nastavení
            if is_bottom and not props.use_ring_bot:
                continue
            if is_top and not props.use_ring_top:
                continue

            if num_rings == 1:
                height = (h_min + h_max) / 2
                ring_radius = radius_mid
            else:
                t = ring_i / (num_rings - 1)
                height = h_min + t * (h_max - h_min)
                if ring_i == 0 or ring_i == num_rings - 1:
                    ring_radius = radius_outer
                else:
                    ring_radius = radius_mid

            # Počet kamer — krajní prstence mají vlastní hodnotu
            if num_rings == 1:
                cams_this_ring = cams_per_ring_mid
            elif ring_i == 0 or ring_i == num_rings - 1:
                cams_this_ring = cams_per_ring_outer
            else:
                cams_this_ring = cams_per_ring_mid

            # Vlastní kolekce pro každý prstenec
            ring_coll = bpy.data.collections.new(f"Ring_{ring_i:02d}")
            root_coll.children.link(ring_coll)

            for cam_i in range(cams_this_ring):
                angle = (2 * math.pi * cam_i) / cams_this_ring
                x = target_loc.x + ring_radius * math.cos(angle)
                y = target_loc.y + ring_radius * math.sin(angle)
                z = target_loc.z + height

                cam_data = bpy.data.cameras.new(f"CamRing{ring_i:02d}_{cam_i:03d}")
                cam_data.lens = fl
                cam_data.sensor_width = 36.0

                cam_obj = bpy.data.objects.new(f"CamRing{ring_i:02d}_{cam_i:03d}", cam_data)
                cam_obj.location = Vector((x, y, z))
                ring_coll.objects.link(cam_obj)

                # Track To constraint
                track = cam_obj.constraints.new('TRACK_TO')
                track.target = target
                track.track_axis = 'TRACK_NEGATIVE_Z'
                track.up_axis = 'UP_Y'

                cam_count += 1

        # Polární kamery
        if props.use_polar_top or props.use_polar_bot:
            polar_coll = bpy.data.collections.new("Ring_Polar")
            root_coll.children.link(polar_coll)

            polar_pairs = []
            if props.use_polar_top:
                polar_pairs.append(("Top", props.polar_height))
            if props.use_polar_bot:
                polar_pairs.append(("Bot", -props.polar_height))

            for label, z_offset in polar_pairs:
                cam_data = bpy.data.cameras.new(f"CamPolar_{label}")
                cam_data.lens = fl
                cam_data.sensor_width = 36.0
                cam_obj = bpy.data.objects.new(f"CamPolar_{label}", cam_data)
                cam_obj.location = Vector((target_loc.x, target_loc.y, target_loc.z + z_offset))
                polar_coll.objects.link(cam_obj)
                track = cam_obj.constraints.new('TRACK_TO')
                track.target = target
                track.track_axis = 'TRACK_NEGATIVE_Z'
                track.up_axis = 'UP_Y'
                cam_count += 1

        self.report({'INFO'}, f"Vytvořeno {cam_count} kamer ve {num_rings} prstencích + polární")
        return {'FINISHED'}


class CRCE_OT_Export(Operator):
    bl_idname = "crce.export"
    bl_label = "Exportovat COLMAP dataset"
    bl_description = "Exportuje cameras.txt, images.txt a volitelně renderuje snímky"

    def execute(self, context):
        props = context.scene.crce_props
        out_path = bpy.path.abspath(props.output_path)
        images_path = os.path.join(out_path, "images")

        os.makedirs(images_path, exist_ok=True)

        # Získej všechny kamery z CameraRings kolekce (včetně podkolekcí Ring_XX)
        coll_name = "CameraRings"
        if coll_name in bpy.data.collections:
            root = bpy.data.collections[coll_name]
            cam_objects = []
            for child in root.children:
                cam_objects += [o for o in child.objects if o.type == 'CAMERA']
            cam_objects += [o for o in root.objects if o.type == 'CAMERA']
            # Seřadit prstence aby Ring_Polar byl nakonec
            cam_objects.sort(key=lambda o: o.name)
        else:
            cam_objects = [o for o in context.scene.objects if o.type == 'CAMERA']

        if not cam_objects:
            self.report({'ERROR'}, "Žádné kamery nenalezeny!")
            return {'CANCELLED'}

        scene = context.scene
        orig_camera = scene.camera
        orig_res_x = scene.render.resolution_x
        orig_res_y = scene.render.resolution_y
        orig_filepath = scene.render.filepath

        scene.render.resolution_x = props.image_width
        scene.render.resolution_y = props.image_height
        scene.render.image_settings.file_format = 'JPEG'
        scene.render.image_settings.quality = 95

        img_w = props.image_width
        img_h = props.image_height

        # --- Soubory rovnou do root složky (LichtFeld nechce sparse/0) ---
        cameras_txt = os.path.join(out_path, "cameras.txt")
        images_txt  = os.path.join(out_path, "images.txt")
        points_txt  = os.path.join(out_path, "points3D.txt")

        # --- cameras.txt ---
        with open(cameras_txt, 'w') as f_cam:
            f_cam.write("# Camera list with one line of data per camera:\n")
            f_cam.write("# CAMERA_ID, MODEL, WIDTH, HEIGHT, PARAMS[]\n")
            f_cam.write("# SIMPLE_PINHOLE: f, cx, cy\n")
            for cam_id, cam_obj in enumerate(cam_objects, start=1):
                cam_data = cam_obj.data
                fl_mm   = cam_data.lens
                sensor  = cam_data.sensor_width
                fx = (fl_mm / sensor) * img_w
                cx = img_w / 2.0
                cy = img_h / 2.0
                f_cam.write(f"{cam_id} SIMPLE_PINHOLE {img_w} {img_h} {fx:.4f} {cx:.4f} {cy:.4f}\n")

        # --- images.txt ---
        R_b2c = Matrix(((1, 0, 0), (0, -1, 0), (0, 0, -1)))

        with open(images_txt, 'w') as f_img:
            f_img.write("# Image list with two lines of data per image:\n")
            f_img.write("# IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME\n")
            f_img.write("# POINTS2D[] as (X, Y, POINT3D_ID)\n")

            for cam_id, cam_obj in enumerate(cam_objects, start=1):
                img_name   = f"{cam_obj.name}.jpg"
                cam_matrix = cam_obj.matrix_world
                R_world    = cam_matrix.to_3x3()
                t_world    = cam_matrix.translation
                R_colmap   = R_b2c @ R_world.transposed()
                t_colmap   = R_colmap @ (-t_world)
                q          = R_colmap.to_quaternion()
                qw, qx, qy, qz = q.w, q.x, q.y, q.z
                tx, ty, tz = t_colmap.x, t_colmap.y, t_colmap.z
                f_img.write(
                    f"{cam_id} {qw:.8f} {qx:.8f} {qy:.8f} {qz:.8f} "
                    f"{tx:.8f} {ty:.8f} {tz:.8f} {cam_id} {img_name}\n\n"
                )

                if props.render_images:
                    scene.camera = cam_obj
                    scene.render.filepath = os.path.join(images_path, cam_obj.name)
                    bpy.ops.render.render(write_still=True)

        # --- points3D.txt z meshů ve scéně ---
        import bmesh
        if props.source_mesh:
            mesh_objects = [props.source_mesh]
        else:
            mesh_objects = [o for o in context.scene.objects
                            if o.type == 'MESH' and o.name not in [c.name for c in bpy.data.collections]]

        with open(points_txt, 'w') as f_pts:
            f_pts.write("# 3D point list with one line of data per point:\n")
            f_pts.write("# POINT3D_ID, X, Y, Z, R, G, B, ERROR, TRACK[]\n")

            pt_id = 1
            for obj in mesh_objects:
                bm = bmesh.new()
                bm.from_mesh(obj.data)
                # Sample max 2000 vertices per mesh
                verts = list(bm.verts)
                step = max(1, len(verts) // 2000)
                for v in verts[::step]:
                    world_co = obj.matrix_world @ v.co
                    x, y, z = world_co.x, world_co.y, world_co.z
                    f_pts.write(f"{pt_id} {x:.6f} {y:.6f} {z:.6f} 128 128 128 0\n")
                    pt_id += 1
                bm.free()

        self.report({'INFO'}, f"Hotovo: {len(cam_objects)} kamer, {pt_id-1} bodů → {out_path}")

        # Obnov původní nastavení
        scene.camera = orig_camera
        scene.render.resolution_x = orig_res_x
        scene.render.resolution_y = orig_res_y
        scene.render.filepath = orig_filepath

        self.report({'INFO'}, f"Export hotov → {out_path}  ({len(cam_objects)} kamer)")
        return {'FINISHED'}




# ---------------------------------------------------------------------------
# Eevee + RTX operator
# ---------------------------------------------------------------------------

class CRCE_OT_EeveeRTX(Operator):
    bl_idname = "crce.eevee_rtx"
    bl_label = "Eevee + RTX"
    bl_description = "Přepne na Eevee a zapne RTX raytracing"

    def execute(self, context):
        context.scene.render.engine = 'BLENDER_EEVEE'
        eevee = context.scene.eevee
        if hasattr(eevee, "use_raytracing"):
            eevee.use_raytracing = True
        else:
            self.report({'WARNING'}, "RTX není v této verzi Eevee dostupné")
        return {'FINISHED'}


class CRCE_OT_Cycles(Operator):
    bl_idname = "crce.cycles"
    bl_label = "Cycles"
    bl_description = "Přepne na Cycles"

    def execute(self, context):
        context.scene.render.engine = 'CYCLES'
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Transparent background toggle
# ---------------------------------------------------------------------------

class CRCE_OT_RenderOnly(Operator):
    bl_idname = "crce.render_only"
    bl_label = "Batch Render"
    bl_description = "Renderuje ze všech kamer bez exportu COLMAP dat"

    def execute(self, context):
        props = context.scene.crce_props
        out_path = bpy.path.abspath(props.output_path)
        images_path = os.path.join(out_path, "images")
        os.makedirs(images_path, exist_ok=True)

        coll_name = "CameraRings"
        if coll_name in bpy.data.collections:
            root = bpy.data.collections[coll_name]
            cam_objects = []
            for child in root.children:
                cam_objects += [o for o in child.objects if o.type == 'CAMERA']
            cam_objects += [o for o in root.objects if o.type == 'CAMERA']
        else:
            cam_objects = [o for o in context.scene.objects if o.type == 'CAMERA']

        if not cam_objects:
            self.report({'ERROR'}, "Žádné kamery nenalezeny!")
            return {'CANCELLED'}

        scene = context.scene
        orig_camera = scene.camera
        orig_filepath = scene.render.filepath
        orig_res_x = scene.render.resolution_x
        orig_res_y = scene.render.resolution_y

        scene.render.resolution_x = props.image_width
        scene.render.resolution_y = props.image_height
        scene.render.image_settings.file_format = 'JPEG'
        scene.render.image_settings.quality = 95

        for cam_obj in cam_objects:
            scene.camera = cam_obj
            scene.render.filepath = os.path.join(images_path, cam_obj.name)
            bpy.ops.render.render(write_still=True)

        scene.camera = orig_camera
        scene.render.filepath = orig_filepath
        scene.render.resolution_x = orig_res_x
        scene.render.resolution_y = orig_res_y

        self.report({'INFO'}, f"Batch render hotov — {len(cam_objects)} snímků → {images_path}")
        return {'FINISHED'}


class CRCE_OT_TranspBG(Operator):
    bl_idname = "crce.transp_bg"
    bl_label = "Průhledné pozadí"
    bl_description = "Zapne/vypne průhledné pozadí při renderu"

    def execute(self, context):
        rd = context.scene.render
        rd.film_transparent = not rd.film_transparent
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Labels CZ / EN
# ---------------------------------------------------------------------------

LABELS = {
    "CZ": {
        "target":       "Cílový objekt",
        "rings":        "Prstence kamer",
        "num_rings":    "Počet prstenců",
        "cams_per":     "Kamer na prstenec",
        "rad_mid":      "Poloměr střední (m)",
        "rad_outer":    "Poloměr krajní (m)",
        "h_min":        "Výška min (m)",
        "h_max":        "Výška max (m)",
        "focal":        "Ohnisková vzdálenost (mm)",
        "create":       "Vytvořit prstence",
        "export_sec":   "COLMAP Export",
        "out_path":     "Výstupní složka",
        "width":        "Šířka",
        "height":       "Výška",
        "render":       "Renderovat snímky",
        "export_btn":   "Exportovat dataset",
        "eevee_rtx":    "Eevee + RTX",
        "cycles":       "Cycles",
        "transp_bg":    "Průhledné pozadí",
        "cams_outer":   "Kamer krajní",
        "source_mesh":  "Zdrojový mesh",
        "polar":        "Polární kamery",
        "polar_h":      "Výška polárních (m)",
    },
    "EN": {
        "target":       "Target Object",
        "rings":        "Camera Rings",
        "num_rings":    "Ring Count",
        "cams_per":     "Cams per Ring",
        "rad_mid":      "Middle Radius (m)",
        "rad_outer":    "Outer Radius (m)",
        "h_min":        "Height Min (m)",
        "h_max":        "Height Max (m)",
        "focal":        "Focal Length (mm)",
        "create":       "Create Rings",
        "export_sec":   "COLMAP Export",
        "out_path":     "Output Folder",
        "width":        "Width",
        "height":       "Height",
        "render":       "Render Images",
        "export_btn":   "Export Dataset",
        "eevee_rtx":    "Eevee + RTX",
        "cycles":       "Cycles",
        "transp_bg":    "Transparent BG",
        "cams_outer":   "Cams Outer",
        "source_mesh":  "Source Mesh",
        "polar":        "Polar Cameras",
        "polar_h":      "Polar Height (m)",
    },
}

# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------

class CRCE_PT_MainPanel(Panel):
    bl_label = "Splat Exporter"
    bl_idname = "CRCE_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "COLMAP"

    def draw(self, context):
        layout = self.layout
        props = context.scene.crce_props
        L = LABELS[props.lang]

        # --- Jazyk ---
        row = layout.row(align=True)
        row.prop(props, "lang", expand=True)

        # --- Rychlé akce ---
        row = layout.row(align=True)
        row.operator("crce.eevee_rtx", text=L["eevee_rtx"], icon='SHADING_RENDERED')
        row.operator("crce.cycles", text="Cycles", icon='OUTLINER_OB_LIGHT')
        transp = context.scene.render.film_transparent
        row.operator("crce.transp_bg", text=L["transp_bg"],
                     icon='WORLD' if not transp else 'OUTLINER_DATA_EMPTY',
                     depress=transp)

        # --- Cíl ---
        box = layout.box()
        box.label(text=L["target"], icon='OBJECT_DATA')
        box.prop(props, "target_object", text="")

        # --- Camera ring nastavení ---
        box = layout.box()
        box.label(text=L["rings"], icon='CAMERA_DATA')
        row = box.row(align=True)
        row.prop(props, "num_rings", text=L["num_rings"])
        box.prop(props, "cams_per_ring", text=L["cams_per"])
        box.prop(props, "cams_per_ring_outer", text=L["cams_outer"])
        box.prop(props, "ring_radius",       text=L["rad_mid"])
        box.prop(props, "ring_radius_outer", text=L["rad_outer"])
        row2 = box.row(align=True)
        row2.prop(props, "height_min", text=L["h_min"])
        row2.prop(props, "height_max", text=L["h_max"])
        box.prop(props, "focal_length", text=L["focal"])
        box.separator()
        # Krajní prstence
        row_rings = box.row(align=True)
        row_rings.prop(props, "use_ring_bot", text="Ring ↓", toggle=True)
        row_rings.prop(props, "use_ring_top", text="Ring ↑", toggle=True)
        # Polární kamery
        row_polar = box.row(align=True)
        row_polar.prop(props, "use_polar_bot", text="Polar ↓", toggle=True)
        row_polar.prop(props, "use_polar_top", text="Polar ↑", toggle=True)
        if props.use_polar_top or props.use_polar_bot:
            box.prop(props, "polar_height", text=L["polar_h"])
        box.separator()
        box.label(text=L["source_mesh"], icon='MESH_DATA')
        box.prop(props, "source_mesh", text="")
        box.operator("crce.create_rings", text=L["create"], icon='MESH_CIRCLE')

        # --- Export nastavení ---
        box = layout.box()
        box.label(text=L["export_sec"], icon='EXPORT')
        box.prop(props, "output_path", text=L["out_path"])
        row3 = box.row(align=True)
        row3.prop(props, "image_width",  text=L["width"])
        row3.prop(props, "image_height", text=L["height"])
        box.prop(props, "render_images", text=L["render"])
        box.operator("crce.export", text=L["export_btn"], icon='FILE_TICK')
        box.operator("crce.render_only", text="Batch Render", icon='RENDER_ANIMATION')


# ---------------------------------------------------------------------------
# Register
# ---------------------------------------------------------------------------

classes = (
    CRCEProperties,
    CRCE_OT_CreateRings,
    CRCE_OT_Export,
    CRCE_OT_EeveeRTX,
    CRCE_OT_Cycles,
    CRCE_OT_RenderOnly,
    CRCE_OT_TranspBG,
    CRCE_PT_MainPanel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.crce_props = PointerProperty(type=CRCEProperties)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.crce_props


if __name__ == "__main__":
    register()
